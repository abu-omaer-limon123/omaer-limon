(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  var header = $('#header'), burger = $('#burger'), menu = $('#menu'), totop = $('#totop');

  /* Mobile menu */
  function closeMenu() {
    menu.classList.remove('open');
    burger.classList.remove('open');
    burger.setAttribute('aria-expanded', 'false');
  }
  burger.addEventListener('click', function () {
    var open = menu.classList.toggle('open');
    burger.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', String(open));
  });

  /* Smooth scrolling (also closes mobile menu) */
  $$('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var id = a.getAttribute('href');
      var target = id.length > 1 ? $(id) : null;
      if (!target) return;
      e.preventDefault();
      closeMenu();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  /* Sticky header, back-to-top, active nav */
  var links = $$('.nav-link');
  var sections = links.map(function (l) { return $(l.getAttribute('href')); });
  function onScroll() {
    var y = window.scrollY;
    header.classList.toggle('scrolled', y > 40);
    totop.classList.toggle('show', y > 500);
    var pos = y + 140, current = 0;
    sections.forEach(function (s, i) { if (s && s.offsetTop <= pos) current = i; });
    if (window.innerHeight + y >= document.body.scrollHeight - 4) current = sections.length - 1;
    links.forEach(function (l, i) { l.classList.toggle('active', i === current); });
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  totop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  /* Scroll reveal */
  var items = $$('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    items.forEach(function (el, i) {
      el.style.transitionDelay = (i % 5) * 70 + 'ms';
      io.observe(el);
    });
  } else {
    items.forEach(function (el) { el.classList.add('in'); });
  }

  /* Portfolio filter */
  var filters = $$('.filter'), works = $$('.work');
  filters.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var f = btn.getAttribute('data-filter');
      filters.forEach(function (b) { b.classList.toggle('active', b === btn); });
      works.forEach(function (w) {
        var show = f === 'all' || w.getAttribute('data-cat') === f;
        w.classList.toggle('hide', !show);
        w.classList.remove('pop');
        if (show) { void w.offsetWidth; w.classList.add('pop'); }
      });
    });
  });

  /* Contact form validation */
  var form = $('#form'), ok = $('#ok');
  function setError(input, msg) {
    var field = input.closest('.field');
    field.classList.toggle('invalid', !!msg);
    $('.err', field).textContent = msg;
    return !msg;
  }
  function validate() {
    var n = form.name, e = form.email, m = form.message, valid = true;
    valid = setError(n, n.value.trim().length < 2 ? 'Enter your name (at least 2 characters).' : '') && valid;
    valid = setError(e, !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.value.trim()) ? 'Enter a valid email address, like name@example.com.' : '') && valid;
    valid = setError(m, m.value.trim().length < 10 ? 'Write a message of at least 10 characters.' : '') && valid;
    return valid;
  }
  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    ok.textContent = '';
    if (validate()) {
      // No backend is connected yet, so the message is not actually sent.
      ok.textContent = 'Thank you! Your message is ready to send once a mail service is connected.';
      form.reset();
    }
  });
  $$('input, textarea', form).forEach(function (el) {
    el.addEventListener('input', function () { if (el.closest('.field').classList.contains('invalid')) validate(); });
  });
})();
