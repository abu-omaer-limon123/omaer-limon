'use strict';

document.documentElement.classList.add('js');

const navbar = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
const toTop = document.getElementById('toTop');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- Mobile menu ---------- */
function setMenu(open) {
  hamburger.classList.toggle('open', open);
  navLinks.classList.toggle('open', open);
  hamburger.setAttribute('aria-expanded', String(open));
  hamburger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
}
hamburger.addEventListener('click', () => setMenu(!navLinks.classList.contains('open')));
navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });
window.addEventListener('resize', () => { if (window.innerWidth > 900) setMenu(false); });

/* ---------- Smooth scrolling (JS fallback for offset) ---------- */
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const id = link.getAttribute('href');
    if (id.length < 2) return;
    const target = document.querySelector(id);
    if (!target) return;
    e.preventDefault();
    const top = target.getBoundingClientRect().top + window.scrollY - navbar.offsetHeight + 1;
    window.scrollTo({ top, behavior: reduceMotion ? 'auto' : 'smooth' });
  });
});

/* ---------- Active nav link + navbar state + back-to-top ---------- */
const sections = [...document.querySelectorAll('main section[id]')];
const navItems = [...document.querySelectorAll('.nav-link')];

function onScroll() {
  const y = window.scrollY;
  navbar.classList.toggle('scrolled', y > 20);
  toTop.classList.toggle('show', y > 600);

  const probe = y + navbar.offsetHeight + window.innerHeight * 0.3;
  let current = sections[0].id;
  sections.forEach(s => { if (probe >= s.offsetTop) current = s.id; });
  // "process" and CTA belong to the Education/Services flow; only highlight links that exist
  navItems.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + current));
}
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }));

/* ---------- Scroll reveal ---------- */
const revealEls = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const io = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  revealEls.forEach(el => {
    // small stagger for siblings in the same grid
    const siblings = el.parentElement ? [...el.parentElement.children].filter(c => c.classList.contains('reveal')) : [];
    el.style.transitionDelay = (siblings.indexOf(el) * 80) + 'ms';
    io.observe(el);
  });
} else {
  revealEls.forEach(el => el.classList.add('visible'));
}

/* ---------- Typing animation (hero title) ---------- */
(function typeTitle() {
  const el = document.getElementById('typedTitle');
  if (!el || reduceMotion) return;
  const text = el.dataset.text;
  let i = 0;
  el.textContent = '';
  const timer = setInterval(() => {
    el.textContent = text.slice(0, ++i);
    if (i >= text.length) clearInterval(timer);
  }, 110);
})();

/* ---------- Contact form validation ---------- */
const form = document.getElementById('contactForm');
const statusEl = document.getElementById('formStatus');

function setError(input, message) {
  const field = input.closest('.field');
  field.classList.toggle('invalid', Boolean(message));
  field.querySelector('.error').textContent = message || '';
  input.setAttribute('aria-invalid', message ? 'true' : 'false');
  return !message;
}

function validate() {
  const name = form.elements.name;
  const email = form.elements.email;
  const message = form.elements.message;
  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());

  const results = [
    setError(name, name.value.trim().length < 2 ? 'Please enter your name.' : ''),
    setError(email, !email.value.trim() ? 'Please enter your email.' : (!emailOk ? 'Please enter a valid email address.' : '')),
    setError(message, message.value.trim().length < 10 ? 'Please write at least 10 characters.' : '')
  ];
  return results.every(Boolean);
}

form.addEventListener('submit', e => {
  e.preventDefault();
  statusEl.textContent = '';
  if (!validate()) return;

  /* No backend is connected yet. To receive messages, connect this form to a
     service (e.g. Formspree, Web3Forms) or your own server endpoint. */
  statusEl.textContent = 'Thank you! Your message is ready to send once a form service is connected.';
  form.reset();
});

form.querySelectorAll('input, textarea').forEach(input => {
  input.addEventListener('input', () => {
    if (input.closest('.field').classList.contains('invalid')) validate();
  });
});
